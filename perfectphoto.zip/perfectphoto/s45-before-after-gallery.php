<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://kretoss.com
 * @since             1.0.0
 * @package           Perfect_Photo
 *
 * @wordpress-plugin
 * Plugin Name:       Perfect Photo
 * Plugin URI:        https://kretoss.com
 * Description:       Perfect Photo  Before & After photo gallery for showing patient results.
 * Version:           1.0.0
 * Author:            Kretoss
 * Author URI:        https://kretoss.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Domain Path:       /languages
 */


if (!defined('S45PDP'))
    define('S45PDP', plugin_dir_path(__FILE__));
if (!defined('S45PU'))
    define('S45PU', plugins_url('', __FILE__));

require_once('include/license-check.php');

require_once('include/gallery-functions.php');
include('include/options.php');
require_once('include/term.php');
require_once('include/taxonomy-features.php');
require_once('include/terms_walker.php');
require_once('include/cases-shortcode.php');
require_once('include/gallery-rest-api.php');
add_filter('template_include', 's45_adult_check', 99);

add_action('template_redirect', 's45_print_single_patient');

add_filter('template_include', 's45_custom_template_loader');

add_action('pre_get_posts', 's45_patient_listing', 1);

add_filter('wp_insert_post_data', 's45_auto_title_single_patient', 10, 2);

add_filter('post_type_link', 's45_post_type_link_filter', 1, 3);

/**
 * Process the custom metabox fields
 */

add_action('save_post', 's45_process_custom_meta_info');

add_action('wp_ajax_s45_reset_patient_order', 's45_reset_patient_order');

add_action('wp_ajax_s45_reorder_patient_gallery', 's45_reorder_patient_gallery');

add_action('admin_menu', 's45PluginMenu', 200);

// Add the ability to setup default procedures.

add_action('admin_menu', 's45_default_procedures_page', 199);

add_action('admin_enqueue_scripts', 's45_admin_enqueue');

add_action('wp_enqueue_scripts', 's45_front_styles');

add_action("admin_head", "s45_upload_admin_head");
add_action('wp_ajax_plupload_action', "s45_plupload_action");

// Ajax script for saving custom field data

add_action('wp_ajax_s45_save_patient', 's45_save_patient');

// Ajax script for saving custom field data

add_action('wp_ajax_s45_delete_patient', 's45_delete_patient');

add_action('wp_ajax_item_sort', 's45_save_item_order');
add_action('wp_ajax_nopriv_item_sort', 's45_save_item_order');

// Rename file for single patient Upload
add_filter('wp_handle_upload_prefilter', 's45_uploaded_file_names', 1, 1);

add_filter('pre_get_document_title', 's45_set_meta_title', 1);
if (!has_filter('wpseo_title'))
    add_filter('wpseo_title', 's45_set_meta_title');

add_filter('aioseo_title', 's45_set_meta_title');

add_action('wp_head', 's45_set_meta_desc', 1);

add_filter('manage_patients_posts_columns', 'patients_posts_columns');
add_action('manage_patients_posts_custom_column', 'patients_posts_custom_column', 10, 2);
add_filter('manage_edit-patients_sortable_columns', 'patients_sortable_columns');

add_action('admin_init', 's45_add_author_caps');
add_action('admin_init', 's45_add_editor_caps');
add_action('admin_init', 's45_add_administrator_caps');
add_action('admin_init', 's45_add_dynamic_hooks', 50);

//add_action('init', 's45_set_posts_per_page');

// Admin area init actions

add_action('admin_init', 'admin_init');

// Activation Hooks

add_action('init', 's45_init_default_options');
add_action('init', 's45_add_rewrite_rules');
add_action('init', 'register_patient_taxonomies');
add_action('init', 'register_patient_cpt');
add_action('init', 'register_new_image_sizes');

add_filter('body_class', function ($classes) {
    $classes[] = 'full-width-content';
    $classes[] = 'content-sidebar';
    $classes[] = 'page-template-wpbakery';
    $classes[] = 's45-gallery';

    unset($classes[array_search('content-sidebar', $classes)]);
    foreach ($classes as $key => $class) {
        if ($class == "content-sidebar") {
            unset($classes[$key]);
        }
    }
    return $classes;
}, 1000);

// Check if the plugin is active
function s45_is_plugin_active($plugin)
{
    return in_array($plugin, (array) get_option('active_plugins', array()));
}

// If the plugin is active, register the REST API route
if (s45_is_plugin_active('perfectphoto/s45-before-after-gallery.php')) {
    add_action('rest_api_init', function () {
        // Allow only specific origins
        $site_url = get_site_url();
        $allowed_origins = ['http://localhost:3000', 'https://perfectphotodoctor.netlify.app', $site_url];

        // Get the origin of the request
        $origin = get_http_origin();

        if (in_array($origin, $allowed_origins)) {
            header("Access-Control-Allow-Origin: " . esc_url_raw($origin));
            header("Access-Control-Allow-Credentials: true");
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
            header("Access-Control-Allow-Headers: Authorization, Content-Type");

            // Handle preflight requests
            if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
                status_header(200);
                exit();
            }
        }
        register_rest_route('s45/v1', '/plugin-status', array(
            'methods' => 'GET',
            'callback' => 's45_plugin_status',
            'permission_callback' => '__return_true',
        ));
    });
}

// Callback function for the REST API endpoint
function s45_plugin_status()
{
    return new WP_REST_Response(array(
        'status' => 'active',
        'success' => true,
        'message' => 'The Perfect Photo plugin active.'
    ), 200);
}

// Basic Authentication for REST API
add_filter('rest_authentication_errors', 's45_rest_api_basic_auth_error');

function s45_rest_api_basic_auth_error($result)
{
    if (!empty($result)) {
        return $result;
    }
    // Get the current REST API request
    $current_route = rest_get_url_prefix() . '/s45/v1/plugin-status';

    // Check if the current route is the /plugin-status endpoint
    if (strpos($_SERVER['REQUEST_URI'], $current_route) !== false) {

        if (!isset($_SERVER['PHP_AUTH_USER'])) {
            return new WP_Error('rest_forbidden', __('No credentials provided.', 's45'), array('status' => 401));
        }

        $username = $_SERVER['PHP_AUTH_USER'];
        $password = $_SERVER['PHP_AUTH_PW'];

        $user = wp_authenticate($username, $password);

        if (is_wp_error($user)) {
            return new WP_Error('rest_forbidden', __('Invalid credentials.', 's45'), array('status' => 403));
        }

        return $result;
    }
}

register_activation_hook(__FILE__, 's45_rewrite_flush');