<?php
get_header('inner'); ?>
<?php
$term_id = get_queried_object()->term_id;
$options = get_option( 's45_options' );
?>
<div class="content-sidebar-wrap">
<main class="content" id="genesis-content">

<div class="breadcrumb">
<span class="breadcrumb-link-wrap" itemprop="itemListElement"><a itemprop="item" href="<?php echo get_bloginfo('url').'/'; ?>" class="breadcrumb-link"><span class="breadcrumb-link-text-wrap" itemprop="name">Home</span></a></span>
	<span class="separator">&nbsp;  | &nbsp;</span>
	<span class="breadcrumb-link-wrap" itemprop="itemListElement"><a property="item" typeof="WebPage" href="<?php echo get_bloginfo('url').'/'.$options['gallery_slug'].'/'; ?>" class="breadcrumb-link"><span class="breadcrumb-link-text-wrap" itemprop="name">Photo Gallery</span></a></span>
	<span class="separator">&nbsp;  | &nbsp;</span>
	<span class="breadcrumb-link-wrap current-page" itemprop="itemListElement" itemscope="" itemtype="https://schema.org/ListItem"><span class="breadcrumb-link-text-wrap" itemprop="name"><?php echo single_cat_title( '', false ); ?></span></span>
</div>

<div class="vc_row wpb_row vc_row-fluid vc_custom_1651254334380 vc_row-has-fill" id="skip-to-content">
	<div class="row">
		<div class="col-sm-12 col-md-12 col-lg-12">

<div class="breast-title-sec desktop-view">
	<h1><?php echo single_cat_title( '', false ); ?></h1>
	<div class="top-home-btn pull-right">
		<a href="<?php echo get_bloginfo('url').'/'.$options['gallery_slug'].'/'; ?>">Gallery Home</a>
	</div>
</div>
<div class="breast-title-sec mobile-view">
	<div class="top-home-btn">
		<a href="<?php echo get_bloginfo('url').'/'.$options['gallery_slug'].'/'; ?>">Gallery Home</a>
	</div>
	<h1><?php echo single_cat_title( '', false ); ?></h1>
</div>
<?php if ( term_description() ) echo term_description();?>
<div class="cases-area">
	<div class="row">
		<div data-interval="false" class="all-case-box-sec">
			<ul class="">
<?php
$patient_number = 1;
$ids = array();
// Get contact page slug
global $query_string;
query_posts( $query_string.'&meta_key=featurewithincat&meta_value=1&orderby=post_date&order=DESC' );
if ( have_posts() ) : ?>
	<?php

	$h = 0;
	while ( have_posts() ) : the_post();
				$perma = get_permalink();
				$perma_arr = explode('/',rtrim($perma,'/'));
				$po_id = end($perma_arr);
				//print_r($post);
				$link = get_bloginfo('url').'/'.$options['gallery_slug'].'/' .$wp_query->queried_object->slug.'/'.$po_id.'/';
		$hideonlive = get_post_meta($post->ID, 'hideonlive', true);
		if ( $hideonlive != 1):
		$ids[] = $post->ID;
	?>
	<li class="li_res item">
		<div class="case-box-cont">
			<div class="cas-title"> Case<span><a href="<?php echo $link;?>">#<?php echo the_title(); ?></a></span></div>
			<?php
			$attachments = get_posts( array(
				'post_type' => 'attachment',
				'posts_per_page' => 2,
				'post_parent' => get_the_ID(),
				//'exclude'     => get_post_thumbnail_id(),
				'orderby' => 'menu_order',
				'order' => 'ASC'
			) );

			if ( $attachments ) : ?>

			<!-- enclose patient photos -->
			<div class="case-pics aa">
				<a href="<?php echo $link;?>">
				<?php // begin individual patient photo //
				$c=1;
				foreach ( $attachments as $attachment ) {
					if ($c == 5) break;
					$class = "post-attachment mime-" . sanitize_title( $attachment->post_mime_type );
					//$img = wp_get_attachment_image_src( $attachment->ID, 'patient-thumb' );
					$img = $attachment->guid;

					if(strstr($img, 'photogallery')){
						//Step 2: uncomment this one after Step 1
						$img = str_replace('.jpg','-200x200.jpg',$img);

						//STEP 1: uncomment this section and click on every procedure category
						//so it generate the 200x200 thumbnails
						//As we have downloaded full size images when importing, so this is manual process
						/*$path = parse_url($img, PHP_URL_PATH);
						$path = $_SERVER['DOCUMENT_ROOT'].$path;
						echo '<span style="display:none;">'.$path.'</span>';
						$update_image = wp_get_image_editor( $path );
						if ( ! is_wp_error( $update_image ) ) {
							$update_image->resize( 200, 200, true );
							$update_image->save();
						}else {
							$error_string = $update_image->get_error_message();
							echo '<div id="message" class="error"><p>' . $error_string . '</p></div>';
						}*/
						//Step 1: ends here
					}else {
						$attachment_img = wp_get_attachment_image_src( $attachment->ID, 'full' );
						$img = $attachment_img[0];
					}

					//echo $img;exit;
					$before_after = '';
					switch ($c) {
						case 1:
							$before_after = "Before";
							break;
						case 2:
							$before_after = "After";
							break;
						case 3:
							$before_after = "Before";
							break;
						case 4:
							$before_after = "After";
							break;
					}
					?>
					<div class="<?php echo strtolower($before_after); ?>-pic bb height<?php echo $h; ?>">
						<div class="bef-aft-img">
							<img src="<?php echo $img; ?>" alt="<?php echo s45_generate_alt_tag(get_the_ID()); ?> - Case <?php echo the_title(); ?> - <?php echo $before_after; ?>">
							<span class="bef-text"><?php echo $before_after;?></span>
						</div>
						<span><?php echo $before_after; ?></span>
					</div>
					<?php
					$c++; } ?>
				</a>
			</div>

		<?php endif; ?>
		<div class="view-case-btn"> <a href="<?php echo $link;?>">View Case Details</a> </div>
		</div>
	</li>
	<?php $h++;$patient_number++;endif;
	endwhile; ?>
<?php endif; ?>



<?php
$patient_number = 1;
$comma_separated_ids = implode(",", $ids);
$cond = "";
if($comma_separated_ids!='')
	$cond = " AND wp_posts.ID NOT IN ($comma_separated_ids)";
global $wpdb;
$aquery = "SELECT SQL_CALC_FOUND_ROWS wp_posts.* FROM {$wpdb->posts} wp_posts 
			LEFT JOIN {$wpdb->term_relationships} wp_term_relationships ON (wp_posts.ID = wp_term_relationships.object_id) 
			WHERE 1=1 $cond
			AND ( wp_term_relationships.term_taxonomy_id IN ($term_id) ) 
			AND wp_posts.post_type = 'patients' AND (wp_posts.post_status = 'publish' OR wp_posts.post_status = 'private') 
			GROUP BY wp_posts.ID
			ORDER BY CAST(SUBSTR(wp_posts.post_title FROM 1) AS UNSIGNED) DESC LIMIT 0, 100";
$all_patients = $wpdb->get_results($aquery, OBJECT);

if(!empty($all_patients)) :
			$h = 0;
	    	foreach ($all_patients as $post) :
				setup_postdata($post);
				$perma = get_permalink();
				$perma_arr = explode('/',rtrim($perma,'/'));
				$po_id = end($perma_arr);
				//print_r($post);
				$link = get_bloginfo('url').'/'.$options['gallery_slug'].'/' .$wp_query->queried_object->slug.'/'.$po_id.'/';
				$hideonlive = get_post_meta($post->ID, 'hideonlive', true);
				if ( $hideonlive != 1):
			?>

			<li class="li_res item">
				<div class="case-box-cont">
					<div class="cas-title"> Case<span><a href="<?php echo $link;?>">#<?php echo the_title(); ?></a></span></div>
					<?php
					$attachments = get_posts( array(
						'post_type' => 'attachment',
                        'post_mime_type'=>array( 'image/jpeg', 'image/gif', 'image/png', 'image/bmp', 'image/tiff', 'image/x-icon' ),
						'posts_per_page' => 2,
						'post_parent' => get_the_ID(),
						//'exclude'     => get_post_thumbnail_id(),
						'orderby' => 'menu_order',
						'order' => 'ASC'
					) );

					if ( $attachments ) : ?>

					<!-- enclose patient photos -->
					<div class="case-pics aa">
						<a href="<?php echo $link;?>">
						<?php // begin individual patient photo //
						$c=1;
						foreach ( $attachments as $attachment ) {
							if ($c == 5) break;
							$class = "post-attachment mime-" . sanitize_title( $attachment->post_mime_type );
							//$img = wp_get_attachment_image_src( $attachment->ID, 'patient-thumb' );
							$img = $attachment->guid;
							if(strstr($img, 'photogallery')){
								//Step 2: uncomment this one after Step 1
								$img = str_replace('.jpg','-200x200.jpg',$img);

								//STEP 1: uncomment this section and click on every procedure category
								//so it generate the 200x200 thumbnails
								//As we have downloaded full size images when importing, so this is manual process
								/*$path = parse_url($img, PHP_URL_PATH);
								$path = $_SERVER['DOCUMENT_ROOT'].$path;
								echo '<span style="display:none;">'.$path.'</span>';
								$update_image = wp_get_image_editor( $path );
								if ( ! is_wp_error( $update_image ) ) {
									$update_image->resize( 200, 200, true );
									$update_image->save();
								}else {
									$error_string = $update_image->get_error_message();
									echo '<div id="message" class="error"><p>' . $error_string . '</p></div>';
								}*/
								//Step 1: ends here
							}else {
								$attachment_img = wp_get_attachment_image_src( $attachment->ID, 'full' );
								$img = $attachment_img[0];
							}
                            // echo '<pre style="display:none;">';
                            // print_r($attachment->ID);
                            // echo '</pre>';
							$before_after = '';
							switch ($c) {
								case 1:
									$before_after = "Before";
									break;
								case 2:
									$before_after = "After";
									break;
								case 3:
									$before_after = "Before";
									break;
								case 4:
									$before_after = "After";
									break;
							}
							?>
							<div class="<?php echo strtolower($before_after); ?>-pic bb height<?php echo $h; ?>">
								<div class="bef-aft-img">
									<img src="<?php echo $img; ?>" alt="<?php echo s45_generate_alt_tag(get_the_ID()); ?> - Case <?php echo the_title() ?> - <?php echo $before_after; ?>">
									<span class="bef-text"><?php echo $before_after;?></span>
								</div>
								<span><?php echo $before_after; ?></span>
							</div>
		                    <?php
		                    $c++; } ?>
						</a>
					</div>

				<?php endif; ?>
				<div class="view-case-btn"> <a href="<?php echo $link;?>">View Case Details</a> </div>
				</div>
			</li>
			<?php $h++;$patient_number++;endif;
			endforeach; ?>
<?php endif; ?>
		</ul>
	</div>
	<div class="desclimer" style="text-align: center; font-weight: bold; width: 70%; font-size: 17px; margin: 0px auto; display: table;">
		<p>*Actual patients shown before and after surgery. Your results may vary. Photos are for education only and are not meant as a guarantee of results.</p>
	</div>
</div>
</div>
</div>

</div>
</div>

</main>
</div>

<?php get_footer(); ?>