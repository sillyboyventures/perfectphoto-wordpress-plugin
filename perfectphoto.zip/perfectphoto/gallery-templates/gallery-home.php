<?php 
get_header('inner'); ?>

<?php 
// Get contact page slug
$s45_options = get_option( 's45_options' );
$terms = get_terms('procedure', array('orderby'=>'term_order','order'=>'ASC','hide_empty'=>false,'parent'=>0) );
?>
<div class="content-sidebar-wrap">
<main class="content" id="genesis-content">	



<div class="breadcrumb">
	<span class="breadcrumb-link-wrap" itemprop="itemListElement"><a itemprop="item" href="<?php echo get_bloginfo('url').'/'; ?>" class="breadcrumb-link"><span class="breadcrumb-link-text-wrap" itemprop="name">Home</span></a></span>
	<span class="separator">&nbsp;  | &nbsp;</span>
	<span class="breadcrumb-link-wrap current-page" itemprop="itemListElement" itemscope="" itemtype="https://schema.org/ListItem"><span class="breadcrumb-link-text-wrap" itemprop="name">Photo Gallery</span>                 </span>
</div>
	

	
<div class="vc_row wpb_row vc_row-fluid vc_custom_1651254334380 vc_row-has-fill" id="skip-to-content">
	<div class="row">
		<div class="col-sm-12 col-md-12 col-lg-12">
			<h1>Before &amp; After Photos</h1>
			<section class="gallery-content">
			<div class="row treatments">
	<?php 
	$i=1;
	foreach ($terms as $term) { 
		$term_meta = get_option( "taxonomy_$term->term_id" );
		if($term_meta['disable_this']!=1):
			$img = tip_plugin_get_terms( $term->term_id );
			
			$image = wp_get_attachment_image_src( $img, 'large' ); ?>

		<div class="text-center treatments-single">
			<?php if ($image[0]) : ?>
			<div class="category-img">
				<img src="<?php echo $image[0];?>" alt="<?php echo $term->name; ?>" border="0" />
			</div>
			<?php endif; ?>
			<div class="category-list">
			<h3><?php echo $term->name;?></h3>
			<?php 
			$args = array( 
				'orderby'   => 'term_order',
				'order'      => 'ASC',
				'parent'     => $term->term_id,
				'hide_empty' => false,
				'fields'     => 'ids'
		
			);
		
			$term_children = get_terms( 'procedure', $args ); ?>
            
			<ul>
			<?php 
			$ii = 1;
			foreach ($term_children as $child) { 
				$term = get_term_by( 'id', $child, 'procedure' ); 
				$term_meta = get_option( "taxonomy_$term->term_id" );
				if($term_meta['disable_this']!=1):
			?>
				<li id="li-<?php echo $ii;?>">
				<?php if($term_meta['ac_notice']==1): ?>
					<a onclick="validateAdult(this);" href="javascript:void(0);" data-href="<?php echo get_term_link( $term );?>" class="proc-ttl-<?php echo $ii;?>"><?php echo $term->name;?></a>
				<?php else: ?>
					<a href="<?php echo get_term_link( $term );?>" class="proc-ttl-<?php echo $ii;?>"><?php echo $term->name;?></a>
				<?php endif; ?>
				</li>
				
			<?php endif; $ii++; } ?>    		
			</ul>
		</div>
		</div>
    <?php endif; $i++; } ?>
	</div>
	</section>
	<div class="desclimer" style="text-align: center; font-weight: bold; width: 70%; font-size: 17px; margin: 0px auto; display: table;">
		<p>*Actual patients shown before and after surgery. Your results may vary. Photos are for education only and are not meant as a guarantee of results.</p>
	</div>

	</div>
	</div>
</div>
	</main>
</div>
<script>
urlafterwarning=window.location.href;
function validateAdult(elm,data){
	if(typeof(data)==="undefined"){
		var url= jQuery(elm).data('href');
        var hascookie=document.cookie;
		if(hascookie.indexOf('adult_popup_gal')!=-1){
			window.location=url;
		}else{
			urlafterwarning=url;
			//$('#warningModal').removeClass('fade').fadeIn('slow');
			jQuery('#warningModal').modal('show');
		}
    }else{
		var date = new Date();
		var name='adult_popup_gal';
		var value='has_value';
		var days=1;
        date.setTime(date.getTime()+(days*24*60*60*1000));
        var expires = "; expires="+date.toGMTString();
		document.cookie = name+"="+value+expires+"; path=/";
		jQuery('#warningModal').modal('hide');
		window.location=urlafterwarning;
	}
}
</script>
<?php get_footer(); ?>