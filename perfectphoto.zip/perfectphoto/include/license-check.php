<?php

// add_action('admin_menu', 'slm_sample_license_menu');
// function slm_sample_license_menu() {
//     add_submenu_page('edit.php?post_type=patients', 'Patient Before and After Gallery', 'Gallery Settings', 'edit_posts', 's45-gallery-settings', 's45_gallery_settings_page');
// }

// function s45_gallery_settings_page() {
//     echo '<div class="wrap">';
//     echo '<h2>Gallery Settings</h2>';
//     // The settings page content can be placed here.
//     echo '<p>Configure your gallery settings here.</p>';
//     echo '</div>';
// }
