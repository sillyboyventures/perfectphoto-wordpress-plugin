<?php


if($_SERVER['REQUEST_METHOD'] == "OPTIONS" &&
    (
        strpos($_SERVER['REQUEST_URI'], '/wp-json/mobile-app/v1/get-procedures') !== false ||
        strpos($_SERVER['REQUEST_URI'], '/wp-json/mobile-app/v1/add-post') !== false
    )){
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Headers: *");
    die;
}
class  Gallery_rest_api

{

    /**

     * Register the routes for the objects of the controller.

     */

    public static function register_routes()

    {
        // $site_url = get_site_url();
        // $allowed_origins = ['http://localhost:3000', 'https://perfectphotodoctor.netlify.app', $site_url];

        // // Get the origin of the request
        // $origin = get_http_origin();

        // if (in_array($origin, $allowed_origins)) {
        //     header("Access-Control-Allow-Origin: " . esc_url_raw($origin));
        //     header("Access-Control-Allow-Credentials: true");
        //     header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
        //     header("Access-Control-Allow-Headers: Authorization, Content-Type");

        //     // Handle preflight requests
        //     if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        //         status_header(200);
        //         exit();
        //     }
        // }
        register_rest_route(

            'mobile-app/v1',

            '/add-post',

            array(

                'methods' => 'POST',

                'callback' => array(__CLASS__, 'add_post_via_api'),

                'permission_callback' => array(__CLASS__, 'check_api_key'),

            )

        );



        register_rest_route(

            'mobile-app/v1',

            '/get-procedures',

            array(

                'methods' => 'POST',

                'callback' => array(__CLASS__, 'get_procedures_by_taxonomy'),

                'permission_callback' => array(__CLASS__, 'check_api_key'),

            )

        );

    }



    /**

     * Check API key validity.

     */

    public static function check_api_key($request)

    {

        $api_key = $request->get_header('X-API-Key');

        if (!$api_key || !self::verify_api_key($api_key)) {

            return new WP_Error('rest_forbidden', esc_html__('Invalid API key.', 'perfectphoto'), array('status' => 401));

        }

        return true;

    }



    /**

     * Verify API key.

     */

    private static function verify_api_key($api_key)

    {

        // Replace with your actual API key validation logic

        return $api_key === 'Kretoss@123';

    }



    /**

     * Get procedures by taxonomy.

     */

    public static function get_procedures_by_taxonomy($request)

    {

        global $wpdb;



        $params = $request->get_params();

        $taxonomy = $params['taxonomy'] ?? '';

        $post_type = $params['post_type'] ?? '';



        if (empty($taxonomy) || empty($post_type)) {

            return new WP_Error('invalid_parameters', __('Taxonomy and post_type are required.edceced', 'perfectphoto'), array('status' => 400));

        }



        if (!taxonomy_exists($taxonomy) || !post_type_exists($post_type)) {

            return new WP_Error('invalid_parameters', __('Invalid taxonomy or post type.', 'perfectphoto'), array('status' => 400));

        }



        $terms = get_terms(

            array(

                'taxonomy' => $taxonomy,

                'hide_empty' => false,

            )

        );



        if (is_wp_error($terms)) {

            return new WP_Error('terms_retrieval_failed', __('Failed to retrieve terms.', 'perfectphoto'), array('status' => 500));

        }



        $latest_post_id = $wpdb->get_var("SELECT ID FROM {$wpdb->posts} ORDER BY ID DESC LIMIT 1");

    

        return rest_ensure_response(

            array(

                'success' => true,

                'message' => __('Procedures retrieved successfully.', 'perfectphoto'),

                'case_number' => intval($latest_post_id),

                'data' => $terms,

            )

        );

    }



    /**

     * Add post via API.

     */

    public static function add_post_via_api($request)

    {

        // Get request parameters

        $params = $request->get_params();



        // Validate request parameters

        if (empty($params['title']) || empty($params['content']) || empty($params['image_urls'])) {

            return new WP_Error('invalid_parameters', 'Title, content, and image URLs are required.', array('status' => 400));

        }



        // Check if the file upload is successful

        if (!function_exists('wp_handle_upload')) {

            require_once ABSPATH . 'wp-admin/includes/file.php';

        }



        // Create a new post

        $post_args = array(

            'post_title' => sanitize_text_field($params['title']),

            'post_content' => wp_kses_post($params['content']),

            'post_status' => 'publish',

            'post_author' => get_current_user_id(),

            'post_type' => 'patients', // You can change this to 'page' or any custom post type

        );



        $post_id = wp_insert_post($post_args);



        wp_set_post_terms($post_id, $params['term_id'], 'procedure');



        update_post_meta($post_id, 'casetitle', sanitize_text_field($params['casetitle']));

        update_post_meta($post_id, 'casenotes', sanitize_text_field($params['casenotes']));

        update_post_meta($post_id, 'surgeoninfo', sanitize_text_field($params['surgeoninfo']));



        if (is_wp_error($post_id)) {

            return new WP_Error('post_creation_failed', 'Failed to create the post.', array('status' => 500));

        }



        // Loop through each image URL

        foreach ($params['image_urls'] as $key => $image_url) {

            // Fetch the image from URL

            $response = wp_remote_get($image_url);



            if (is_wp_error($response)) {

                // If download fails, delete the post and return error

                wp_delete_post($post_id, true);

                return new WP_Error('download_failed', 'Failed to download image from URL: ' . $image_url, array('status' => 500));

            }



            $image_data = wp_remote_retrieve_body($response);



            // Generate a unique filename for the image

            $filename = wp_unique_filename(wp_upload_dir()['path'], basename($image_url));



            // Save the image to the uploads directory

            $upload_file = wp_upload_bits($filename, null, $image_data);



            if ($upload_file['error']) {

                // If saving fails, delete the post and return error

                wp_delete_post($post_id, true);

                return new WP_Error('upload_failed', 'Failed to save image to server: ' . $upload_file['error'], array('status' => 500));

            }



            // Construct the attachment data

            $attachment = array(

                'post_mime_type' => wp_check_filetype($filename)['type'],

                'post_title' => preg_replace('/\.[^.]+$/', '', basename($filename)),

                'post_content' => '',

                'post_status' => 'inherit',

                'guid' => $upload_file['url'],

                'post_author' => get_current_user_id(),

                'post_parent' => $post_id, // Set the parent post ID

            );



            // Insert the attachment

            $attachment_id = wp_insert_attachment($attachment, $upload_file['file'], $post_id);



            if (!is_wp_error($attachment_id)) {

                // Generate attachment metadata

                require_once ABSPATH . 'wp-admin/includes/image.php';

                $attachment_data = wp_generate_attachment_metadata($attachment_id, $upload_file['file']);



                // Update attachment metadata

                wp_update_attachment_metadata($attachment_id, $attachment_data);



                // Set the first attached image as post thumbnail

                if ($key === 0) {

                    set_post_thumbnail($post_id, $attachment_id);

                }

            } else {

                // If attachment insertion fails, delete the post and return error

                wp_delete_post($post_id, true);

                return new WP_Error('attachment_failed', 'Failed to attach image to post.', array('status' => 500));

            }

        }



        // Return the ID of the newly created post

        return array('post_id' => $post_id);

    }

}

// Register the routes when the rest_api_init hook is fired.

add_action('rest_api_init', array('Gallery_Rest_API', 'register_routes'));

