<?php 
function s45_gallery_shortcode( $atts = array()) {
	
	$flickity_url = S45PU . '/css/flickity.css';
	$flickity_directory = S45PDP . '/css/flickity.css';
	
	wp_register_style('s45_flickity', $flickity_url, array(), filemtime( $flickity_directory ), 'all');
	wp_enqueue_style('s45_flickity');
	
	wp_register_script('s45-flickity-js', S45PU . '/js/flickity.pkgd.min.js',array('jquery'));
	wp_enqueue_script('s45-flickity-js');
	
	$options = get_option( 's45_options' );
	$cat = $posts_per_page = '';
	extract(shortcode_atts(array(
		'limit' 				=> '5',
		'procedure' 				=> '',
		'ids' 				=> '',
		'nudity' 	=> '',
		'title' 	=> ''
	), $atts));
	
	if( $procedure )
		 $cat = $procedure; 
	else
		return false;
	
	$term = get_term_by('slug', $cat, 'procedure'); 
	if(!$term->term_id)
		return false;
	
	$term_id = $term->term_id;
	$patient_number = 1;
	
	$img_class = $nudity_class = '';
	$autoPlay = 'autoPlay';
	if($nudity == true){
		$img_class = 'nudity-blur';
		$nudity_class = 'nudity-class';
		$autoPlay = '';
	}
	
	$result = '<style>
	.js-flickity{
	  background-color: rgba(241, 241, 241, 1);
      padding: 20px 0;
      margin: 25px 0px;
	}
	.gallery-cell {
	  width: 100%;
	  margin-right: 10px;
	}
	.gallery-cell .cas-title {
		font-size: 16px;
		margin-top: 6px;
		margin-bottom: 14px;
		text-align: center;
		color: #824d59;text-transform: uppercase;
	}
	.gallery-cell .cas-title span {
		margin-left: 3px;
	}
	.gallery-cell .cas-title a {
		color: #4a5cb7;
	}
	.gallery-cell .case-pics {
		width: 100%;
		display: block;
		height: auto;
		margin: 0px auto;
		text-align: center;
	}
	.gallery-cell .case-pics a {
		display: inline-block;
		width: 100%;text-decoration: none;
	}
	.gallery-cell .case-pics .before-pic {
		background-color: rgba(241, 241, 241, 1);
		margin-right: 0px;
		position: relative;
		text-align: center;
		width: 46.4%;
		display: inline-block;
		vertical-align: top;
	}

	.gallery-cell .case-pics .after-pic {
		background-color: rgba(241,241,241,1.00);
		text-align: center;
		width: 46.4%;
		position: relative;
		display: inline-block;
		vertical-align: top;
	}
	.gallery-cell .view-case-btn {
		display: inline-block;
		text-align: center;
		width: 100%;
		margin-top: 17px;
	}

	.gallery-cell .view-case-btn a {
		background: #4a5cb7;
		font-size: 14px;
		line-height: 28px;
		text-align: center;
		text-decoration: none;
		padding: 6px 5px;
		width: 184px;
		display: inline-block;
		text-transform: uppercase;
		color: #fff;
	}
	.gallery-cell .view-case-btn a:hover {
		background: #fff;
		color: #4a5cb7;
	}
	.gallery-cell .case-pics .before-pic .bef-aft-img, .gallery-cell .case-pics .after-pic .bef-aft-img{
		
	}
	.gallery-cell .case-pics .before-pic .bef-aft-img img, .gallery-cell .case-pics .after-pic .bef-aft-img img {
		max-width: 97%;
		height: 180px;
		object-fit: cover;
		object-position: center top;
	}
	.nudity-class .flickity-prev-next-button, .flickity-page-dots{display:none;}
	.nudity-class .cas-title, .nudity-class .view-case-btn{
		visibility: hidden;
	}
	.nudity-class img{
		-webkit-filter: blur(5px);
		filter: blur(9px);
		opacity: 0.3;
	}
	.sensitive-content{
		margin: auto;
		position: absolute;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
		padding: 0 50px;
		color: #000;
		height: 100%;
		cursor: pointer;
	}
	.sensitive-content p{color: #000; padding-top: 15%;font-size: 20px;}
	.flickity-h2{
		border: 0;
		color: #000 !important;
		background-color: rgba(241, 241, 241, 1) !important;
		margin-bottom: 0px !important;
		border-radius: initial !important;
		text-align: center;
		padding-top: 20px !important;
		font-weight: bold !important;
	}
	.flickity-button:hover{color: #000;}
	@media (max-width: 767px) {
		.js-flickity{
		  margin: 0px;
		}
		.gallery-cell .case-pics .before-pic .bef-aft-img img, .gallery-cell .case-pics .after-pic .bef-aft-img img {
			height: 150px;
		}
		.sensitive-content{
			padding: 0px 10px;
			font-size: 12px;
			line-height: initial;
		}
		.sensitive-content p{padding-top: 10%;font-size: 16px;line-height: initial;}
	}
	</style>
	<script>
	jQuery(document).ready(function(){
		var $carousel = jQuery(".main-gallery").flickity({
		  cellAlign: "left",
		  contain: true,
		  pageDots: false,';
	if($autoPlay=="autoPlay"){
	$result .= '
		  autoPlay: true,
		  draggable: true
	';}
	$result .= '
		});';
		
	if($autoPlay=="autoPlay"){
	$result .= '
		$carousel.flickity("playPlayer");
	';}
	
	$result .= '
		var flkty = $carousel.data("flickity");
		$carousel.on( "staticClick.flickity", onSelect );
		
		function onSelect() {
			if ( flkty.player.state === "stopped" ) {
				$carousel.flickity("playPlayer");
			}
		}
		
		jQuery(".sensitive-content").click(function(){
			jQuery(".sensitive-content").css("display","none");
			jQuery(".main-gallery").removeClass("nudity-class");
		});
	});
	</script>
	';
	
	$where = '';
	if($ids != ''){
		$ids = rtrim($ids,',');
		$where = ' AND wp_posts.ID IN ('.$ids.') ';
	}else{
		$posts_per_page = ' LIMIT 0, '.$limit;
	}
	global $query_string, $wpdb, $wp_query;
	$fquery = "SELECT SQL_CALC_FOUND_ROWS wp_posts.* FROM {$wpdb->posts} wp_posts
	LEFT JOIN {$wpdb->term_relationships} wp_term_relationships ON (wp_posts.ID = wp_term_relationships.object_id)
	INNER JOIN {$wpdb->postmeta} wp_postmeta ON ( wp_posts.ID = wp_postmeta.post_id )
	WHERE 1=1 AND ( wp_term_relationships.term_taxonomy_id IN ($term_id) ) AND ( ( wp_postmeta.post_id IS NULL OR wp_postmeta.meta_key = 'featurewithincat' ) )
	AND wp_posts.post_type = 'patients' AND (wp_posts.post_status = 'publish' OR wp_posts.post_status = 'private') $where
	GROUP BY wp_posts.ID
	ORDER BY wp_postmeta.meta_value DESC, CAST(SUBSTR(wp_posts.post_title FROM 1) AS UNSIGNED) DESC $posts_per_page";
	
	$featured_patients = $wpdb->get_results($fquery, OBJECT);
	
	if(!empty($featured_patients)) :
		$pnbutton = '';
		if(count($featured_patients) == 1){
			$pnbutton = ', "prevNextButtons": false';
		}
		$result .= '<div class="s45-shortcode-container">';
		if($title != ''){
			$result .= '<h2 class="flickity-h2">'.$title.'</h2>';
		}
		$result .= '<div class="main-gallery js-flickity '.$nudity_class.'">';
		$h = 0;
		foreach ($featured_patients as $post) :
			setup_postdata($post);
			$hideonlive = get_post_meta($post->ID, 'hideonlive', true);
			$link = get_bloginfo('url').'/'.$options['gallery_slug'].'/' .$cat.'/'.$post->post_name.'/';
			$procedure_link = get_bloginfo('url').'/'.$options['gallery_slug'].'/' .$cat.'/';
			//echo '<pre>'; print_r($post);exit;
			if ( $hideonlive != 1):
				$result .='<div class="gallery-cell">';
				
				$result .='<div class="cas-title"> Case<span><a href="'.$link.'">#'.$post->post_title.'</a></span></div>';

				$attachments = get_posts( array(
					'post_type' => 'attachment',
                    'post_mime_type'=>array( 'image/jpeg', 'image/gif', 'image/png', 'image/bmp', 'image/tiff', 'image/x-icon' ),
					'posts_per_page' => 2,
					'post_parent' => $post->ID,
					'orderby' => 'menu_order',
					'order' => 'ASC'
				) );

				if ( $attachments ) :
			
				$result .='<div class="case-pics aa">';
					
					$c=1;
					foreach ( $attachments as $attachment ) {
						if ($c == 5) break;
						$class = "post-attachment mime-" . sanitize_title( $attachment->post_mime_type );
						$img = $attachment->guid;

						if(strstr($img, 'photogallery')){
							//Step 2: uncomment following code after Step 1
							$img_new = str_replace('.jpg','-200x200.jpg',$img);
							$path = parse_url($img_new, PHP_URL_PATH);
							$path = $_SERVER['DOCUMENT_ROOT'].$path;
							if(file_exists( $path )){
								$img = $img_new;
							}							
						}else {
							$attachment_img = wp_get_attachment_image_src( $attachment->ID, 'full' );
							$img = $attachment_img[0];
						}
						$before_after = '';
						switch ($c) {
							case 1:
								$before_after = "Before";
								break;
							case 2:
								$before_after = "After";
								break;
							case 3:
								$before_after = "Before";
								break;
							case 4:
								$before_after = "After";
								break;
						}
						
						$result .='<div class="'.strtolower($before_after).'-pic bb height'.$h.'">
							<div class="bef-aft-img">
								<img src="'.$img.'" alt="Case '.$post->post_title.' - '.$before_after.'">
							</div>
							<span>'.$before_after.'</span>
						</div>';
						
						$c++;
					}
					if($nudity == true){
					$result .= '<div id="sensitive-content" class="sensitive-content"><p><b>Sensitive Content</b><br>These before and after photos contain nudity. Please click/tap to view the images.</p></div>';
					}
					$result .='</div>';
			
			endif;
			$result .='<div class="view-case-btn"> <a href="'.$procedure_link.'">View All Cases</a> </div>';
				
				
				$result .='</div>';
			$h++;$patient_number++;endif;
		endforeach;
		$result .= '</div>';
	$result .= '</div>';
	endif;
	
	return $result;
}
add_shortcode('s45-gallery-items','s45_gallery_shortcode');