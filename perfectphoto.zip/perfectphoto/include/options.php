<?php
function s45_plugin_options() {
    
    $options = get_option('s45_options');

    if (isset($_POST['form_submit']))
    {   
        $options['gallery_slug'] = isset($_POST['gallery_slug']) ? $_POST['gallery_slug'] : '';
        $options['doctor_name'] = isset($_POST['doctor_name']) ? $_POST['doctor_name'] : '';
        $options['contact_slug'] = isset($_POST['contact_slug']) ? $_POST['contact_slug'] : '';
        $options['adult_check_text'] = isset($_POST['adult_check_text'])   ? $_POST['adult_check_text'] : '';
        $options['print_button'] = isset($_POST['print_button']) ? $_POST['print_button'] : '';
		$options['gallery_meta_title'] = isset($_POST['gallery_meta_title']) ? $_POST['gallery_meta_title'] : '';
		$options['gallery_meta_desc'] = isset($_POST['gallery_meta_desc'])   ? $_POST['gallery_meta_desc'] : '';
		$options['glisting_meta_title'] = isset($_POST['glisting_meta_title']) ? $_POST['glisting_meta_title'] : '';
		$options['glisting_meta_desc'] = isset($_POST['glisting_meta_desc']) ? $_POST['glisting_meta_desc'] : '';
		$options['patient_meta_title'] = isset($_POST['patient_meta_title']) ? $_POST['patient_meta_title'] : '';
		$options['patient_meta_desc'] = isset($_POST['patient_meta_desc']) ? $_POST['patient_meta_desc'] : '';
		$options['patient_page_default'] = isset($_POST['patient_page_default']) ? $_POST['patient_page_default'] : '';

        ?><div class="updated fade"><p>Settings Saved</p></div><?php

        update_option('s45_options', $options);  
        
        flush_rewrite_rules();
    }
                        
    ?>

    <div class="wrap"> 
    <div id="icon-settings" class="icon32"></div>
    <h2>Patient Before and After Gallery Settings</h2>

    <form id="form_data" name="form" method="post" style="max-width: 800px;">   
        <br />
        <table class="form-table">
            <tbody>

                <tr class="form-field" valign="top">
                    <th scope="row" style="text-align: right;"><label>Gallery path</label></th>
                    <td>
                        <input type="text" name="gallery_slug" value="<?php if ($options['gallery_slug']) : echo $options['gallery_slug']; endif;?>" />
						<p class="description">i.e. before-after-gallery</p>
                    </td>
                </tr>
                
                <tr class="form-field" valign="top">
                    <th scope="row" style="text-align: right;"><label>Doctor name</label></th>
                    <td>
                       <input type="text" name="doctor_name" value="<?php if (isset($options['doctor_name']) && $options['doctor_name']) : echo $options['doctor_name']; endif;?>" />
                    </td>
                </tr>
                
                <tr class="form-field" valign="top">
                    <th scope="row" style="text-align: right;"><label>Contact us page slug</label></th>
                    <td>
                       <input type="text" name="contact_slug" value="<?php if (isset($options['contact_slug']) && $options['contact_slug']) : echo $options['contact_slug']; endif;?>" />
						<p class="description">i.e. contact-us</p>
					</td>
                </tr>
                
                 <tr class="form-field" valign="top">
                    <th scope="row" style="text-align: right;"><label>Adult check text</label></th>
                    <td>
                       <textarea  rows="5" cols="50" class="large-text" name="adult_check_text"><?php echo ( isset($options['adult_check_text']) ? $options['adult_check_text'] : '' );?> </textarea>
                    </td>
                </tr>

                <tr class="form-field" valign="top">
                    <th scope="row" style="text-align: right;"><label>Enable print button on single patient view</label></th>
                    <td>
                       <input type="checkbox" name="print_button" value="on" <?php if (isset($options['print_button']) && $options['print_button'] == 'on') echo 'checked';?>/>
                    </td>
                </tr>
				
				<tr class="form-field" valign="top">
                    <th scope="row" style="text-align: right;"><label>Gallery Home Page Meta Title</label></th>
                    <td>
						<input type="text" name="gallery_meta_title" value="<?php if (isset($options['gallery_meta_title']) && $options['gallery_meta_title']) : echo $options['gallery_meta_title']; endif;?>" />
						<p class="description">Cosmetic Surgery, Patient Before and After Photo Gallery | Dr. Name</p>
					</td>
                </tr>
				
				<tr class="form-field" valign="top">
                    <th scope="row" style="text-align: right;"><label>Gallery Home Page Meta Description</label></th>
                    <td>
                       <textarea  rows="5" cols="50" class="large-text" name="gallery_meta_desc"><?php echo ( isset($options['gallery_meta_desc']) ? $options['gallery_meta_desc'] : '' );?> </textarea>
                    </td>
                </tr>
				
				<tr class="form-field" valign="top">
                    <th scope="row" style="text-align: right;"><label>Gallery Listing Page Meta Title</label></th>
                    <td>
                       <input type="text" name="glisting_meta_title" value="<?php if (isset($options['glisting_meta_title']) && $options['glisting_meta_title']) : echo $options['glisting_meta_title']; endif;?>" />
						<p class="description">Use following tags to generate listing page title: [category_name] [doctor_name] [site_title] i.e. [category_name] Patient Photo Gallery | [doctor_name]</p>
					</td>
                </tr>
				
				<tr class="form-field" valign="top">
                    <th scope="row" style="text-align: right;"><label>Gallery Listing Page Meta Description</label></th>
                    <td>
                       <textarea rows="5" cols="50" class="large-text" name="glisting_meta_desc"><?php echo ( isset($options['glisting_meta_desc']) ? $options['glisting_meta_desc'] : '' );?> </textarea>
						<p class="description">Use following tags to generate listing page description: [category_name] [doctor_name] [site_title] i.e. [category_name] Before and After Photos Gallery by [doctor_name] - [site_title]</p>
					</td>
                </tr>
				
				<tr class="form-field" valign="top">
                    <th scope="row" style="text-align: right;"><label>Gallery Patient Page Meta Title</label></th>
                    <td>
						<input type="text" name="patient_meta_title" value="<?php if (isset($options['patient_meta_title']) && $options['patient_meta_title']) : echo $options['patient_meta_title']; endif;?>" />
						<p class="description">Use following tags to generate patient page title: [case] [category_name] [doctor_name] [site_title] i.e. Before and After Photos Gallery - [category_name] - [case] - [site_title]</p>
					</td>
                </tr>
				
				<tr class="form-field" valign="top">
                    <th scope="row" style="text-align: right;"><label>Gallery Patient Page Meta Description</label></th>
                    <td>
                       <textarea  rows="5" cols="50" class="large-text" name="patient_meta_desc"><?php echo ( isset($options['patient_meta_desc']) ? $options['patient_meta_desc'] : '' );?> </textarea>
						<p class="description">Use following tags to generate patient page title: [case] [category_name] [doctor_name] [site_title] i.e. Before and After Photos Gallery - [category_name] - [case] - [site_title]</p>
					</td>
                </tr>
				
				<tr class="form-field" valign="top">
                    <th scope="row" style="text-align: right;"><label>Patient Page Left Default Content</label></th>
                    <td>
                       <textarea  rows="5" cols="50" class="large-text" name="patient_page_default"><?php echo ( isset($options['patient_page_default']) ? $options['patient_page_default'] : '' );?> </textarea>
						<p class="description">This text will be the default text on left side of patient page.</p>
					</td>
                </tr>
                
            </tbody>
        </table>
        

        <p class="submit">
            <input type="submit" name="Submit" class="button-primary" value="<?php _e('Save Settings', 'to') ?>">
        </p>

        <input type="hidden" name="form_submit" value="true" />
        
    </form>

    <h2>Reset gallery order to default</h2>
    <p>This command will reset the order to the entire photo gallery based on date uploaded.</p>
    <p>Warning: this cannot be undone.</p>
    <a href="#" id="reset-patient-order" class="button-primary" title="Reset gallery order">Reset Gallery Order</a>
    <div id="response" style="margin:1em 0"></div>
    <?php  
        echo '</div>';
    }
function get_gal_db_info(){
	$mydb = new wpdb('martinps','kBsEvfgUQv_P8HDrTAFl','wp_martinps','localhost');
	return $mydb;
}

function s45_case_images($case_id,$post_id){
	$wpdb = get_gal_db_info();
	$images = $wpdb->get_results("SELECT * FROM `images` WHERE `case_id` = ".$case_id." ORDER BY `id` DESC;");
	$images_list = array();
	if(!empty($images)){
		foreach ($images as $image) :		
			// Get the path to the upload directory.
			$wp_upload_dir = wp_upload_dir();
			
			$filename1 = $wp_upload_dir['path']. '/' .$image->image_before;
			$filename2 = $wp_upload_dir['path']. '/' .$image->image_after;
			
			// The ID of the post this attachment is for.
			$parent_post_id = $post_id;

			// Check the type of file. We'll use this as the 'post_mime_type'.
			$filetype1 = wp_check_filetype( basename( $filename1 ), null );
			$filetype2 = wp_check_filetype( basename( $filename2 ), null );

			// Prepare an array of post data for the attachment before image
			$attachment1 = array(
				'guid'           => $wp_upload_dir['url'] . '/' . basename( $filename1 ), 
				'post_mime_type' => $filetype1['type'],
				'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $filename1 ) ),
				'post_content'   => '',
				'post_status'    => 'inherit'
			);

			// Insert the attachment.
			$attach_id1 = wp_insert_attachment( $attachment1, $filename1, $parent_post_id );
			
			// Prepare an array of post data for the attachment after image
			$attachment2 = array(
				'guid'           => $wp_upload_dir['url'] . '/' . basename( $filename2 ), 
				'post_mime_type' => $filetype2['type'],
				'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $filename2 ) ),
				'post_content'   => '',
				'post_status'    => 'inherit'
			);

			// Insert the attachment.
			$attach_id2 = wp_insert_attachment( $attachment2, $filename2, $parent_post_id );
			
			
			// Make sure that this file is included, as wp_generate_attachment_metadata() depends on it.
			require_once( ABSPATH . 'wp-admin/includes/image.php' );

			// Generate the metadata for the attachment, and update the database record.
			$attach_data1 = wp_generate_attachment_metadata( $attach_id1, $filename1 );
			wp_update_attachment_metadata( $attach_id1, $attach_data1 );
			set_post_thumbnail( $parent_post_id, $attach_id1 );
			
			// Generate the metadata for the attachment, and update the database record.
			$attach_data2 = wp_generate_attachment_metadata( $attach_id2, $filename2 );
			wp_update_attachment_metadata( $attach_id2, $attach_data2 );
			set_post_thumbnail( $parent_post_id, $attach_id2 );

		endforeach;
	}
}

function s45_cat_cases($cat_id, $term_id){
	$wpdb = get_gal_db_info();
	
	//loading cases with cat_id
	$cases = $wpdb->get_results("SELECT c.* FROM `case_category` cc LEFT JOIN `cases` c ON cc.`cases_id` = c.`case_id` WHERE cc.`cat_id` = ".$cat_id." ORDER BY `c`.`case_id` DESC;");

	if(!empty($cases)){
		foreach ($cases as $case) :
			//Create post object --- saving cases as posts
			$my_post = array(
			  'post_title'    => $case->case_id,
			  'post_content'  => $case->case_description,
			  'post_status'   => 'publish',
			  'post_author'   => 1,
			  'post_type' 	  => 'patients',
			);
			 
			// Insert the post into the database
			$post_id = wp_insert_post( $my_post );
			
			if($case->case_status==0)
				update_post_meta($post_id, 'hideonlive', 1);
			
			if($case->case_featured==1)
				update_post_meta($post_id, 'featurewithincat', 1);
			
			if($case->case_lookup!='')
				update_post_meta($post_id, 'casetitle', $case->case_lookup);
			
			if($case->case_notes!='')
				update_post_meta($post_id, 'casenotes', $case->case_notes);
			
			//wp_set_object_terms( $post_id, array( $term_id ), 'procedure', true);
			wp_set_post_terms( $post_id, array( $term_id ), 'procedure' );
			
			//loading images for case
			s45_case_images($case->case_id,$post_id);
			
		endforeach;
	}
}

function s45_plugin_import() {
	$wpdb = get_gal_db_info();
	
	//echo '<pre>';print_r(wp_upload_dir());exit;
	//loading parent categories
	$parent_rows = $wpdb->get_results("select * from categories where category_id = 1;");
	$categories_list = array();
	foreach ($parent_rows as $obj) :
			$parent_url = $obj->category_url;
			$parent_cat_name = $obj->category_name;
			$parent_cat_id = $obj->category_id;
			//echo '<pre>';print_r($obj);exit;
			//inserting wordpress terms
			if (!term_exists( $parent_cat_name, 'procedure' )) {
				wp_insert_term( $parent_cat_name, 'procedure', array());
				$parent_term = term_exists( $parent_cat_name, 'procedure' );
				$parent_term_id = $parent_term['term_id'];
				
				//loading parent category cases
				//s45_cat_cases($parent_cat_id,$parent_term_id);
				
				//loading child categories
				$child_rows = $wpdb->get_results("select * from categories where category_parent = ".$parent_cat_id.";");
				if(!empty($child_rows)){
					foreach ($child_rows as $obj_child) :
						$child_cat_id = $obj_child->category_id;
						$child_url = $obj_child->category_url;
						$child_cat_name = $obj_child->category_name;
						
						//inserting wordpress terms
						if (!term_exists( $child_cat_name, 'procedure' )) {
							wp_insert_term( $child_cat_name, 'procedure', array( 'parent' => $parent_term_id ));
							$child_term = term_exists( $child_cat_name, 'procedure' );
							$child_term_id = $child_term['term_id'];
							
							//loading parent category cases
							s45_cat_cases($child_cat_id,$child_term_id);
						}
						
					endforeach;
					delete_option('procedure_children');
				}
				delete_option('procedure_children');
			}
	endforeach;
}

function s45_instructions(){
	$html = '<style type="text/css">.redText{color:#ff0000;}</style>';
	$html .= '<div class="wrap">
	<h1>Instructions</h1>
	<h2>Gallery Settings</h2>
	<ol>
		<li><b>Gallery path:</b> The ending portion of the URL to pull up the gallery. <span class="redText">It is recommended that this not be changed.</span></li>
		<li><b>Doctor Name:</b> This name will display onthe single patient details pages. This name will display by default on all single patient case pages, unless you fill in the “Surgeon” field on the edit Patient page.</li>
		<li><b>Thumbnail and Regular image size:</b> How large the thumbnail and regular images should be. <span class="redText">It is recommended that this not be changed.</span></li>
		<li><b>Contact Us page slug:</b> Like the gallery path, this is the ending part of the URL for the contact page. <span class="redText">It is recommended that this not be changed.</span></li>
		<li><b>Adult Check Text:</b> When a gallery procedure (category) has the “Display Adult Content Notice” option checked, the text within this field is what will be shown to people before that procedure/category can be opened and viewed.</li>
		<li><b>Gallery Home Page Meta Title & Descriptions:</b> These options are SEO related and whatever content you add here will be shown on title and description.<span class="redText">It is recommended that this not be changed.</span></li>
		<li><b>Gallery Listing Page Meta Title:</b> Just like with the Meta Title and descriptions, this dynamically generates SEO friendly titles. <span class="redText">It is recommended that this not be changed.</span></li>
		<li><b>Patient Page Left Default Content:</b> This text will display on each case before the contact us button.</li>
	</ol>
	<h2>Add a New Case</h2>
	<ol>
		<li>Within the admin dashboard, navigate to Perfect Photo -> Add New Patient</li>
		<li>Here you will find the title, description and other case details for the patient.<br /><br />
			<img src="' . plugins_url( '../images/one.png' , __FILE__ ) . '" /> <br />
			As you can see 348 is the case title, and the description is written in the box. At the right side, we have selected the procedure (category).<br /><br />
			<img src="' . plugins_url( '../images/two.png' , __FILE__ ) . '" /> <br />
		</li>
		<li>To upload the images, please follow these instructions:<br /><br />
			<img src="' . plugins_url( '../images/three.png' , __FILE__ ) . '" /> <br />
			It will prompt a new popup<br /><br />
			<img src="' . plugins_url( '../images/four.png' , __FILE__ ) . '" style="max-width: 100%;" /> <br /><br />
			After uploading, you have the option to automatically crop your images to a specific aspect ratio under the “Display Options” area:<br /><br />
			<img src="' . plugins_url( '../images/five.png' , __FILE__ ) . '" style="max-width: 100%;" /> <br /><br />
			1:1 which results in a perfectly square image<br />
			4:3 which results in a traditional landscape oriented image<br />
			Default which does not crop the image automatically<br /><br />
			<img src="' . plugins_url( '../images/seven.png' , __FILE__ ) . '" /> <br />
			To upload more images, repeat the steps above.<br /><br />
		</li>
	</ol>
	<h2>Delete a case</h2>
		<img src="' . plugins_url( '../images/tweleve.png' , __FILE__ ) . '" /> <br />
		<img src="' . plugins_url( '../images/thirteen.png' , __FILE__ ) . '" /> <br />
	<h2>Add New Procedure</h2>
	<ol>
		<li>From the admin dashboard, navigate to Perfect Photo > Procedures <br /><br />
			<img src="' . plugins_url( '../images/fourteen.png' , __FILE__ ) . '" /> <br />
		</li>
	</ol>
	<h2>Change Procedures Order</h2>
	<ol>
		<li>We can simply drag the procedures up or down to change their order.<br /><br />
		<img src="' . plugins_url( '../images/fifteen.png' , __FILE__ ) . '" /> <br />
		</li>
	</ol>
	<h2>Edit Procedure</h2>
	<p>To edit a procedure, navigate to the admin dashboard and then Perfect Photo -> Procedures. Mouse over any procedure and click the “Edit” link for that procedure.</p>
	<ol>
		<li><b>Name:</b> The name of the procedure/category.</li>
		<li><b>Slug:</b> The ending URL portion for the procedure’s web address. It is best to keep this simple and to use dashes instead of spaces, for example breast-augmentation.</li>
		<li><b>Parent Category:</b> Set this if you wish for your procedure to be nested under another (for example, Breast Augmentation would have a parent of Breast).</li>
		<li><b>Description:</b> This is blank by default. <span class="redText">It is recommended that this not be changed.</span></li>
		<li><b>Display Adult Content Notice:</b> Check this box to have the adult content warning/notice pop up when someone tries to view this procedure’s gallery page.</li>
		<li><b>Disable This Procedure:</b> Check this box to remove the procedure from the website. Note that it will remain in Procedures in the site back-end, users just will not be able to view it.</li>
	</ol>
	<h2>Display Specific Category or Case with Shortcode</h2>
	<p>You can now showcase your individual before and after patients using a simple shortcode anywhere on your site!</p>
	<img src="' . plugins_url( '../images/six.png' , __FILE__ ) . '" style="max-width: 100%;" /> <br /><br />
	<p>To use these shortcodes,substitute the procedure slug for the one you want to display, then paste the shortcode in any page or post where you’d like to have it shown. </p>
	<p>You can find any of your procedure’s slugs by going to Perfect Photo > Procedures and the slug is the third column, labelled “Slug.” Simply copy and paste the slug to replace any of the example codes given below and it will then show the new procedure you have chosen.</p>
	<ol>
		<li>Load 5 cases from a certain procedure <b>[s45-gallery-items procedure="eyelid-lift" limit=5]</b> </li>
		<li>Show only one case (the first case) from a procedure, with no slider icons: <b>[s45-gallery-items procedure="eyelid-lift" limit=1]</b>  </li>
		<li>Show specific procedure cases only using case ID: <b>[s45-gallery-items procedure="eyelid-lift" ids="3696,3703"]</b> </li>
	</ol>
	<p>To find a specific gallery case’s ID, go to Perfect Photo > Patients and click “Edit” on any of your cases. Look up at the web address bar after the edit case page has loaded. You will see something like this: https://www.sector45.com/wp-admin/post.php?post=13175&action=edit <br>
	Your case ID is the number after post= so in this example the case ID is 13175. Using this ID with the last shortcode listed above, you can display only that case within a shortcode if desired.</p>
	</div>';
	echo $html;
}
?>