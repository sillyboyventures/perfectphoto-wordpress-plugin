<?php

	add_filter( 'manage_procedure_custom_column', 'taxonomy_image_plugin_taxonomy_rows', 15, 3 );
	add_filter( 'manage_edit-procedure_columns',  'taxonomy_image_plugin_taxonomy_columns' );
	add_action( 'procedure_edit_form_fields', 'taxonomy_image_plugin_edit_tag_form', 10, 2 );
	add_action( 'admin_enqueue_scripts', 'taxonomy_images_admin_enqueue_scripts' );
	add_action( 'wp_ajax_taxonomy_image_create_association', 'taxonomy_image_plugin_create_association' );
	add_action( 'wp_ajax_taxonomy_image_plugin_remove_association', 'taxonomy_image_plugin_remove_association' );
	add_action( 'wp_ajax_update-taxonomy-order', 'TOsaveAjaxOrder' );
	add_filter('get_terms_orderby', 'TO_get_terms_orderby', 1, 2);
	add_action('admin_menu', 'taxonomy_order_menu', 200 );
	
	function taxonomy_order_menu(){
		add_submenu_page('edit.php?post_type=patients', __('Taxonomy Order', 'taxonomy-terms-order'), __('Taxonomy Order', 'taxonomy-terms-order'), 'manage_options', 'to-interface-patients', 'TOPluginInterface' );
	}
	
	function taxonomy_images_admin_enqueue_scripts() {
		wp_enqueue_media();
		wp_enqueue_script(
			'taxonomy-images-media-modal',
			S45PU. '/js/media-modal.js',
			array( 'jquery' ),
			3.5
		);
		
		wp_enqueue_script('jquery-ui-sortable');
            
		$myJsFile = S45PU . '/js/to-javascript.js';
		wp_register_script('to-javascript', $myJsFile);
		wp_enqueue_script( 'to-javascript');
		
		wp_localize_script( 'taxonomy-images-media-modal', 'TaxonomyImagesMediaModal', array(
			'wp_media_post_id'     => 0,
			'attachment_id'        => 0,
			'uploader_title'       => __( 'Featured image', 'taxonomy-images' ),
			'uploader_button_text' => __( 'Set featured image', 'taxonomy-images' ),
			'default_img_src'      =>  S45PU.'/images/default-img.png'
		) );
		
		wp_enqueue_style(
			'taxonomy-image-plugin-edit-tags',
			S45PU.'/css/admin.css',
			array(),
			1.5,
			'screen'
		);
		
		$myCssFile = S45PU . '/css/to.css';
		wp_register_style('to.css', $myCssFile);
		wp_enqueue_style( 'to.css');
	}
	
	function taxonomy_image_plugin_taxonomy_columns( $original_columns ) {
		$new_columns = $original_columns;
		array_splice( $new_columns, 1 );
		$new_columns['taxonomy_image_plugin'] = esc_html__( 'Image', 'taxonomy-images' );
		return array_merge( $new_columns, $original_columns );
	}
	
	function taxonomy_image_plugin_taxonomy_rows( $row, $column_name, $term_id ) {
		if ( 'taxonomy_image_plugin' === $column_name ) {
			global $taxonomy;
			return $row . taxonomy_image_plugin_control_image( $term_id, $taxonomy );
		}
		return $row;
	}
	
	function taxonomy_image_plugin_control_image( $term_id, $taxonomy ) {

		$t = new Taxonomy_Images_Term( $term_id, $taxonomy );

		$term = $t->get_term();
		$tt_id = $t->get_tt_id();

		$taxonomy = get_taxonomy( $t->get_taxonomy() );

		$name = esc_html__( 'term', 'taxonomy-images' );
		if ( isset( $taxonomy->labels->singular_name ) ) {
			$name = strtolower( $taxonomy->labels->singular_name );
		}

		$attachment_id = $t->get_image_id();
		$hide = $attachment_id ? '' : ' hide';

		$img = taxonomy_image_plugin_get_image_src( $attachment_id );

		$nonce = wp_create_nonce( 'taxonomy-image-plugin-create-association' );
		$nonce_remove = wp_create_nonce( 'taxonomy-image-plugin-remove-association' );

		$thickbox_class = '';

		$o  = "\n" . '<div id="' . esc_attr( 'taxonomy-image-control-' . $tt_id ) . '" class="taxonomy-image-control hide-if-no-js">';
		$o .= "\n" . '<a class="' . $thickbox_class . ' taxonomy-image-thumbnail" data-tt-id="' . $tt_id . '" data-attachment-id="' . $attachment_id . '" data-nonce="' . $nonce . '" href="' . esc_url( admin_url( 'media-upload.php' ) . '?type=image&tab=library&post_id=0&TB_iframe=true' ) . '" title="' . esc_attr( sprintf( __( 'Associate an image with the %1$s named &#8220;%2$s&#8221;.', 'taxonomy-images' ), $name, $term->name ) ) . '"><img width="75" id="' . esc_attr( 'taxonomy_image_plugin_' . $tt_id ) . '" src="' . esc_url( $img ) . '" alt="" /></a>';
		$o .= "\n" . '<a class="control upload ' . $thickbox_class . '" data-tt-id="' . $tt_id . '" data-attachment-id="' . $attachment_id . '" data-nonce="' . $nonce . '" href="' . esc_url( admin_url( 'media-upload.php' ) . '?type=image&tab=type&post_id=0&TB_iframe=true' ) . '" title="' . esc_attr( sprintf( __( 'Upload a new image for this %s.', 'taxonomy-images' ), $name ) ) . '">' . esc_html__( 'Upload.', 'taxonomy-images' ) . '</a>';
		$o .= "\n" . '<a class="control remove' . $hide . '" data-tt-id="' . $tt_id . '" data-nonce="' . $nonce_remove . '" href="#" id="' . esc_attr( 'remove-' . $tt_id ) . '" rel="' . esc_attr( $tt_id ) . '" title="' . esc_attr( sprintf( __( 'Remove image from this %s.', 'taxonomy-images' ), $name ) ) . '">' . esc_html__( 'Delete', 'taxonomy-images' ) . '</a>';
		$o .= "\n" . '<input type="hidden" class="tt_id" name="' . esc_attr( 'tt_id-' . $tt_id ) . '" value="' . esc_attr( $tt_id ) . '" />';
		$o .= "\n" . '<input type="hidden" class="image_id" name="' . esc_attr( 'image_id-' . $tt_id ) . '" value="' . esc_attr( $attachment_id ) . '" />';

		if ( isset( $term->name ) && isset( $term->slug ) ) {
			$o .= "\n" . '<input type="hidden" class="term_name" name="' . esc_attr( 'term_name-' . $term->slug ) . '" value="' . esc_attr( $term->name ) . '" />';
		}

		$o .= "\n" . '</div>';
		return $o;
	}
	
	function taxonomy_image_plugin_sanitize_associations( $associations ) {
		$o = array();
		foreach ( (array) $associations as $tt_id => $im_id ) {
			$tt_id = absint( $tt_id );
			$im_id = absint( $im_id );
			if ( 0 < $tt_id && 0 < $im_id )
				$o[ $tt_id ] = $im_id;
		}
		return $o;
	}
	
	function taxonomy_image_plugin_get_associations( $refresh = false ) {
		static $associations = array();
		if ( empty( $associations ) || $refresh ) {
			$associations = taxonomy_image_plugin_sanitize_associations( get_option( 'taxonomy_image_plugin' ) );
		}

		return $associations;
	}
	
	function taxonomy_image_plugin_detail_image_size() {
		return array(
			'name' => 'detail',
			'size' => array( 75, 75, true )
		);
	}
	
	function taxonomy_image_plugin_get_image_src( $id ) {
		$detail = taxonomy_image_plugin_detail_image_size();

		/* Return url to custom intermediate size if it exists. */
		$img = image_get_intermediate_size( $id, $detail['name'] );
		if ( isset( $img['url'] ) ) {
			return $img['url'];
		}

		// Detail image does not exist, attempt to create it.
		$wp_upload_dir = wp_upload_dir();

		if ( isset( $wp_upload_dir['basedir'] ) ) {

			/* Create path to original uploaded image. */
			$path = trailingslashit( $wp_upload_dir['basedir'] ) . get_post_meta( $id, '_wp_attached_file', true );
			if ( is_file( $path ) ) {

				// Attempt to create a new downsized version of the original image
				$new = wp_get_image_editor( $path );

				// Image editor instance OK
				if ( ! is_wp_error( $new ) ) {

					$resized = $new->resize(
						$detail['size'][0],
						$detail['size'][1],
						absint( $detail['size'][2] )
					);

					// Image resize successful. Generate and cache image metadata. Return url.
					if ( ! is_wp_error( $resized ) ) {

						$path = $new->generate_filename();
						$new->save( $path );

						$meta = wp_generate_attachment_metadata( $id, $path );
						wp_update_attachment_metadata( $id, $meta );
						$img = image_get_intermediate_size( $id, $detail['name'] );

						if ( isset( $img['url'] ) ) {
							return $img['url'];
						}

					}

				}

			}

		}

		/* Custom intermediate size cannot be created, try for thumbnail. */
		$img = image_get_intermediate_size( $id, 'thumbnail' );
		if ( isset( $img['url'] ) ) {
			return $img['url'];
		}

		/* Thumbnail cannot be found, try fullsize. */
		$url = wp_get_attachment_url( $id );
		if ( ! empty( $url ) ) {
			return $url;
		}

		/**
		 * No image can be found.
		 * This is most likely caused by a user deleting an attachment before deleting it's association with a taxonomy.
		 * If we are in the administration panels:
		 * - Delete the association.
		 * - Return uri to default.png.
		 */
		if ( is_admin() ) {
			$assoc = taxonomy_image_plugin_get_associations();
			foreach ( $assoc as $term => $img ) {
				if ( $img === $id ) {
					unset( $assoc[ $term ] );
				}
			}
			update_option( 'taxonomy_image_plugin', $assoc );

			return S45PU .'/images/default-img.png';

		}

		/*
		 * No image can be found.
		 * Return path to blank-image.png.
		 */
		return S45PU.'/images/blank.png';

	}
	
	function taxonomy_image_plugin_edit_tag_form( $term, $taxonomy ) {
		$taxonomy = get_taxonomy( $taxonomy );
		$name = __( 'term', 'taxonomy-images' );
		if ( isset( $taxonomy->labels->singular_name ) )
			$name = strtolower( $taxonomy->labels->singular_name );
		?>
		<tr class="form-field hide-if-no-js">
			<th scope="row" valign="top"><label for="description"><?php print esc_html__( 'Featured Image', 'taxonomy-images' ) ?></label></th>
			<td>
				<?php print taxonomy_image_plugin_control_image( $term->term_id, $taxonomy->name ); ?>
				<div class="clear"></div>
				<span class="description"><?php printf( esc_html__( 'Associate an image from your media library to this %1$s.', 'taxonomy-images' ), esc_html( $name ) ); ?></span>
			</td>
		</tr>
		<?php
	}
	
	function taxonomy_image_plugin_json_response( $args ) {
		/* translators: An ajax request has failed for an unknown reason. */
		$response = wp_parse_args( $args, array(
			'status' => 'bad',
			'why'    => esc_html__( 'Unknown error encountered', 'taxonomy-images' )
		) );

		wp_send_json( $response );

	}
	
	function taxonomy_image_plugin_create_association() {
		if ( ! isset( $_POST['tt_id'] ) ) {
			taxonomy_image_plugin_json_response( array(
				'status' => 'bad',
				'why'    => esc_html__( 'tt_id not sent', 'taxonomy-images' ),
			) );
		}

		$tt_id = absint( $_POST['tt_id'] );
		if ( empty( $tt_id ) ) {
			taxonomy_image_plugin_json_response( array(
				'status' => 'bad',
				'why'    => esc_html__( 'tt_id is empty', 'taxonomy-images' ),
			) );
		}

		if ( ! isset( $_POST['wp_nonce'] ) ) {
			taxonomy_image_plugin_json_response( array(
				'status' => 'bad',
				'why'    => esc_html__( 'No nonce included.', 'taxonomy-images' ),
			) );
		}

		if ( ! wp_verify_nonce( $_POST['wp_nonce'], 'taxonomy-image-plugin-create-association' ) ) {
			taxonomy_image_plugin_json_response( array(
				'status' => 'bad',
				'why'    => esc_html__( 'Nonce did not match', 'taxonomy-images' ),
			) );
		}

		if ( ! isset( $_POST['attachment_id'] ) ) {
			taxonomy_image_plugin_json_response( array(
				'status' => 'bad',
				'why'    => esc_html__( 'Image id not sent', 'taxonomy-images' )
			) );
		}

		$image_id = absint( $_POST['attachment_id'] );
		if ( empty( $image_id ) ) {
			taxonomy_image_plugin_json_response( array(
				'status' => 'bad',
				'why'    => esc_html__( 'Image id is not a positive integer', 'taxonomy-images' )
			) );
		}

		$t = new Taxonomy_Images_Term( $tt_id, true );

		if ( ! $t->current_user_can_edit() ) {
			taxonomy_image_plugin_json_response( array(
				'status' => 'bad',
				'why'    => esc_html__( 'You do not have the correct capability to manage this term', 'taxonomy-images' ),
			) );
		}

		if ( $t->update_image_id( $image_id ) ) {
			taxonomy_image_plugin_json_response( array(
				'status' => 'good',
				'why'    => esc_html__( 'Image successfully associated', 'taxonomy-images' ),
				'attachment_thumb_src' => taxonomy_image_plugin_get_image_src( $image_id )
			) );
		} else {
			taxonomy_image_plugin_json_response( array(
				'status' => 'bad',
				'why'    => esc_html__( 'Association could not be created', 'taxonomy-images' )
			) );
		}

		/* Don't know why, but something didn't work. */
		taxonomy_image_plugin_json_response();
	}
	
	function taxonomy_image_plugin_remove_association() {
		if ( ! isset( $_POST['tt_id'] ) ) {
			taxonomy_image_plugin_json_response( array(
				'status' => 'bad',
				'why'    => esc_html__( 'tt_id not sent', 'taxonomy-images' ),
			) );
		}

		$tt_id = absint( $_POST['tt_id'] );
		if ( empty( $tt_id ) ) {
			taxonomy_image_plugin_json_response( array(
				'status' => 'bad',
				'why'    => esc_html__( 'tt_id is empty', 'taxonomy-images' ),
			) );
		}

		if ( ! isset( $_POST['wp_nonce'] ) ) {
			taxonomy_image_plugin_json_response( array(
				'status' => 'bad',
				'why'    => esc_html__( 'No nonce included', 'taxonomy-images' ),
			) );
		}

		if ( ! wp_verify_nonce( $_POST['wp_nonce'], 'taxonomy-image-plugin-remove-association') ) {
			taxonomy_image_plugin_json_response( array(
				'status' => 'bad',
				'why'    => esc_html__( 'Nonce did not match', 'taxonomy-images' ),
			) );
		}

		$t = new Taxonomy_Images_Term( $tt_id, true );

		if ( ! $t->current_user_can_edit() ) {
			taxonomy_image_plugin_json_response( array(
				'status' => 'bad',
				'why'    => esc_html__( 'You do not have the correct capability to manage this term', 'taxonomy-images' ),
			) );
		}

		$img = $t->get_image_id();

		if ( ! $img ) {
			taxonomy_image_plugin_json_response( array(
				'status' => 'good',
				'why'    => esc_html__( 'Nothing to remove', 'taxonomy-images' )
			) );
		}

		if ( $t->delete_image_id() ) {
			taxonomy_image_plugin_json_response( array(
				'status' => 'good',
				'why'    => esc_html__( 'Association successfully removed', 'taxonomy-images' )
			) );
		} else {
			taxonomy_image_plugin_json_response( array(
				'status' => 'bad',
				'why'    => esc_html__( 'Association could not be removed', 'taxonomy-images' )
			) );
		}

		/* Don't know why, but something didn't work. */
		taxonomy_image_plugin_json_response();
	}
	
	function TOPluginInterface() {
		global $wpdb, $wp_locale;
		
		$taxonomy = isset($_GET['taxonomy']) ? sanitize_key($_GET['taxonomy']) : '';
		$post_type = isset($_GET['post_type']) ? sanitize_key($_GET['post_type']) : '';
		if(empty($post_type))
			{
				$screen = get_current_screen();
				
				if(isset($screen->post_type)    && !empty($screen->post_type))
					$post_type  =   $screen->post_type;
					else
					{
						switch($screen->parent_file)
							{
								case "upload.php" :
													$post_type  =   'attachment';
													break;
											
								default:
													$post_type  =   'post';   
							}
					}       
			} 
										
		$post_type_data = get_post_type_object($post_type);
		
		if (!taxonomy_exists($taxonomy))
			$taxonomy = '';

		?>
		<div class="wrap">
			<div class="icon32" id="icon-edit"><br></div>
			<h2><?php _e( "Taxonomy Order", 'taxonomy-terms-order' ) ?></h2>
			
			<div id="ajax-response"></div>

			<div class="clear"></div>
			
			<?php
			
				$current_section_parent_file    =   '';
				switch($post_type)
					{
						
						case "attachment" :
										$current_section_parent_file    =   "upload.php";
										break;
										
						default :
										$current_section_parent_file    =    "edit.php";
										break;
					}
			
			
			?>
			
			<form action="<?php echo $current_section_parent_file ?>" method="get" id="to_form">
				<input type="hidden" name="page" value="to-interface-<?php echo esc_attr($post_type) ?>" />
				<?php
			
				 if (!in_array($post_type, array('post', 'attachment'))) 
					echo '<input type="hidden" name="post_type" value="'. esc_attr($post_type) .'" />';

				//output all available taxonomies for this post type
				
				$post_type_taxonomies = get_object_taxonomies($post_type);
			
				foreach ($post_type_taxonomies as $key => $taxonomy_name)
					{
						$taxonomy_info = get_taxonomy($taxonomy_name);  
						if ($taxonomy_info->hierarchical !== TRUE) 
							unset($post_type_taxonomies[$key]);
					}
					
				//use the first taxonomy if emtpy taxonomy
				if ($taxonomy == '' || !taxonomy_exists($taxonomy))
					{
						reset($post_type_taxonomies);   
						$taxonomy = current($post_type_taxonomies);
					}
										
				if (count($post_type_taxonomies) > 1)
					{
			
						?>
						
						<h2 class="subtitle"><?php echo ucfirst($post_type_data->labels->name) ?> <?php _e( "Taxonomies", 'taxonomy-terms-order' ) ?></h2>
						<table cellspacing="0" class="wp-list-taxonomy">
							<thead>
							<tr>
								<th style="" class="column-cb check-column" id="cb" scope="col">&nbsp;</th><th style="" class="" id="author" scope="col"><?php _e( "Taxonomy Title", 'taxonomy-terms-order' ) ?></th><th style="" class="manage-column" id="categories" scope="col"><?php _e( "Total Posts", 'taxonomy-terms-order' ) ?></th>    </tr>
							</thead>


							<tbody id="the-list">
							<?php
								
								$alternate = FALSE;
								foreach ($post_type_taxonomies as $post_type_taxonomy)
									{
										$taxonomy_info = get_taxonomy($post_type_taxonomy);

										$alternate = $alternate === TRUE ? FALSE :TRUE;
										
										$args = array(
													'hide_empty'    =>  0,
													'taxonomy'      =>  $post_type_taxonomy
													);
										$taxonomy_terms = get_terms( $args );
														 
										?>
											<tr valign="top" class="<?php if ($alternate === TRUE) {echo 'alternate ';} ?>" id="taxonomy-<?php echo esc_attr($taxonomy)  ?>">
													<th class="check-column" scope="row"><input type="radio" onclick="to_change_taxonomy(this)" value="<?php echo $post_type_taxonomy ?>" <?php if ($post_type_taxonomy == $taxonomy) {echo 'checked="checked"';} ?> name="taxonomy">&nbsp;</th>
													<td class="categories column-categories"><b><?php echo $taxonomy_info->label ?></b> (<?php echo  $taxonomy_info->labels->singular_name; ?>)</td>
													<td class="categories column-categories"><?php echo count($taxonomy_terms) ?></td>
											</tr>
										
										<?php
									}
							?>
							</tbody>
						</table>
						<br />
						<?php
					}
						?>

			<div id="order-terms">
				
  
				
				<div id="post-body">                    
					
						<ul class="sortable" id="tto_sortable">
							<?php 
								listTerms($taxonomy); 
							?>
						</ul>
						
						<div class="clear"></div>
				</div>
				
				<div class="alignleft actions">
					<p class="submit">
						<a href="javascript:;" class="save-order button-primary"><?php _e( "Update", 'taxonomy-terms-order' ) ?></a>
					</p>
				</div>
				
			</div> 

			</form>
			
			<script type="text/javascript">
				jQuery(document).ready(function() {
					
					jQuery("ul.sortable").sortable({
							'tolerance':'intersect',
							'cursor':'pointer',
							'items':'> li',
							'axi': 'y',
							'placeholder':'placeholder',
							'nested': 'ul'
						});
					  
					jQuery(".save-order").bind( "click", function() {
							var mySortable = new Array();
							jQuery(".sortable").each(  function(){
								
								var serialized = jQuery(this).sortable("serialize");
								
								var parent_tag = jQuery(this).parent().get(0).tagName;
								parent_tag = parent_tag.toLowerCase()
								if (parent_tag == 'li')
									{
										// 
										var tag_id = jQuery(this).parent().attr('id');
										mySortable[tag_id] = serialized;
									}
									else
									{
										//
										mySortable[0] = serialized;
									}
							});
							
							//serialize the array
							var serialize_data = JSON.stringify( convArrToObj(mySortable));
																						
							jQuery.post( ajaxurl, { action:'update-taxonomy-order', order: serialize_data, nonce : '<?php echo wp_create_nonce( 'update-taxonomy-order' ); ?>' }, function() {
								jQuery("#ajax-response").html('<div class="message updated fade"><p><?php _e( "Items Order Updated", 'taxonomy-terms-order' ) ?></p></div>');
								jQuery("#ajax-response div").delay(3000).hide("slow");
							});
						});
					
  
				});
				
			</script>
			
		</div>
		<?php 	
	}
	
	function listTerms($taxonomy){

		// Query pages.
		$args = array(
					'orderby'       =>  'term_order',
					'depth'         =>  0,
					'child_of'      => 0,
					'hide_empty'    =>  0
		);
		$taxonomy_terms = get_terms($taxonomy, $args);

		$output = '';
		if (count($taxonomy_terms) > 0)
			{
				$output = TOwalkTree($taxonomy_terms, $args['depth'], $args);    
			}

		echo $output; 
		
	}
        
	function TOwalkTree($taxonomy_terms, $depth, $r) {
			$walker = new TO_Terms_Walker; 
			$args = array($taxonomy_terms, $depth, $r);
			return call_user_func_array(array(&$walker, 'walk'), $args);
	}
	
    function TO_get_terms_orderby($orderby, $args){
		if ( apply_filters('to/get_terms_orderby/ignore', FALSE, $orderby, $args) )
			return $orderby;
			
		if (isset($args['orderby']) && $args['orderby'] == "term_order" && $orderby != "term_order")
			return "t.term_order";
			
		return $orderby;
	}
	
	function TOsaveAjaxOrder() {
		global $wpdb;
		
		if  ( ! wp_verify_nonce( $_POST['nonce'], 'update-taxonomy-order' ) )
			die();
		 
		$data               = stripslashes($_POST['order']);
		$unserialised_data  = json_decode($data, TRUE);
				
		if (is_array($unserialised_data))
		foreach($unserialised_data as $key => $values ) 
			{
				//$key_parent = str_replace("item_", "", $key);
				$items = explode("&", $values);
				unset($item);
				foreach ($items as $item_key => $item_)
					{
						$items[$item_key] = trim(str_replace("item[]=", "",$item_));
					}
				
				if (is_array($items) && count($items) > 0)
				foreach( $items as $item_key => $term_id ) 
					{
						$wpdb->update( $wpdb->terms, array('term_order' => ($item_key + 1)), array('term_id' => $term_id) );
					} 
			}
			
		do_action('tto/update-order');
			
		die();
	}
?>